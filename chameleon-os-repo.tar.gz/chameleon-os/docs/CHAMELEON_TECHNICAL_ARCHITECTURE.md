# CHAMELEON OS: Technische Architektur für Produktvarianten

## 🏗️ KERN-ARCHITEKTUR-PRINZIPIEN

### 1. Separation of Concerns (SoC)
```
┌──────────────────────────────────────────────────────────────┐
│ LAYER 1: CORE (Unveränderlich, geteilt)                     │
├──────────────────────────────────────────────────────────────┤
│ - Hardware Abstraction Layer (HAL)                           │
│ - LVGL Framework                                             │
│ - Chameleon Framework (Theme, Carousel, Gesten)             │
│ - Connectivity (WiFi, NTP, OTA)                             │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ LAYER 2: APPS (Modular, austauschbar)                       │
├──────────────────────────────────────────────────────────────┤
│ - 33 spezialisierte Apps (Sector A-F)                       │
│ - Jede App ist völlig unabhängig                            │
│ - Apps kommunizieren über standardisierte APIs              │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ LAYER 3: PRODUCT CONFIG (Produktspezifisch)                 │
├──────────────────────────────────────────────────────────────┤
│ - Welche Apps sind aktiv?                                    │
│ - Welches Theme?                                             │
│ - Welche Hardware-Features?                                  │
│ - Welche APIs sind verfügbar?                               │
└──────────────────────────────────────────────────────────────┘
```

### 2. Konfigurationsbasierte Kompilierung
**Nicht**: Alle 33 Apps in einer Firmware
**Sondern**: Nur die Apps, die für dieses Produkt nötig sind

```
WiFi Analyzer Produkt:
├── core/ (immer)
├── apps/sector_c/wifi_analyzer.c (nur diese App)
└── products/wifi_analyzer/config.json (Konfiguration)
    ↓
    Kompiliert zu: ~1.2 MB Firmware (nicht 5+ MB)
```

### 3. Standardisierte App-Interface
Jede App muss diese Schnittstelle implementieren:

```c
// app_interface.h
typedef struct {
    const char* app_name;
    const char* app_version;
    const char* sector;
    
    // Lifecycle
    void (*app_init)(void);
    void (*app_deinit)(void);
    void (*app_start)(void);
    void (*app_stop)(void);
    
    // Rendering
    void (*app_render)(void);
    void (*app_update)(void);
    
    // Interaction
    void (*app_on_touch)(touch_event_t event);
    void (*app_on_button)(button_event_t event);
    
    // Configuration
    void (*app_configure)(config_t* config);
    config_t* (*app_get_config)(void);
    
    // Metadata
    const char* (*app_get_icon)(void);
    const char* (*app_get_description)(void);
    
} app_t;
```

---

## 📁 VERZEICHNISSTRUKTUR (DETAILLIERT)

```
chameleon-os/
│
├── core/
│   ├── hal/                           # Hardware Abstraction Layer
│   │   ├── display/
│   │   │   ├── st7789.c              # ST7789 Treiber
│   │   │   ├── st7789.h
│   │   │   ├── dma_config.c          # DMA für Display
│   │   │   └── framebuffer.c         # Double-Buffering
│   │   ├── touch/
│   │   │   ├── cst816s.c             # CST816S Treiber
│   │   │   ├── cst816s.h
│   │   │   ├── gesture.c             # Gesture-Erkennung
│   │   │   └── calibration.c         # Touch-Kalibrierung
│   │   ├── power/
│   │   │   ├── power.c               # Stromverwaltung
│   │   │   ├── battery.c             # Batterie-Monitoring
│   │   │   └── sleep_modes.c         # Sleep/Wake-Up
│   │   ├── connectivity/
│   │   │   ├── wifi.c                # WiFi-Treiber
│   │   │   ├── ntp.c                 # Zeit-Synchronisation
│   │   │   ├── ota.c                 # Over-The-Air Updates
│   │   │   └── provisioning.c        # Captive Portal
│   │   └── hal.h                     # HAL-Interface
│   │
│   ├── framework/
│   │   ├── theme/
│   │   │   ├── theme_manager.c       # Zentrale Theme-Verwaltung
│   │   │   ├── theme_manager.h
│   │   │   ├── themes/
│   │   │   │   ├── obsidian_gold.c
│   │   │   │   ├── nordic_white.c
│   │   │   │   ├── industrial_blue.c
│   │   │   │   ├── cyberpunk_neon.c
│   │   │   │   └── [weitere Themes]
│   │   │   └── theme.h               # Theme-Struktur
│   │   ├── navigation/
│   │   │   ├── carousel.c            # Carousel-Widget
│   │   │   ├── carousel.h
│   │   │   └── app_launcher.c        # App-Launcher
│   │   ├── components/
│   │   │   ├── slider.c              # Kreis-Slider
│   │   │   ├── graph.c               # Graphen-Widget
│   │   │   ├── gauge.c               # Gauge-Widget
│   │   │   ├── button.c              # Button-Widget
│   │   │   └── [weitere Komponenten]
│   │   └── framework.h               # Framework-Interface
│   │
│   ├── lvgl_config/
│   │   ├── lv_conf.h                 # LVGL Konfiguration
│   │   ├── lv_drivers.c              # LVGL Treiber-Integration
│   │   └── lv_memory.c               # LVGL Memory-Management
│   │
│   └── core.h                        # Core-Interface
│
├── apps/                             # Die 33 Apps
│   ├── app_interface.h               # Standard App-Interface
│   ├── app_registry.c                # App-Registrierung
│   ├── app_registry.h
│   │
│   ├── sector_a/                     # Smart Home & Ambient
│   │   ├── thermostat/
│   │   │   ├── thermostat.c
│   │   │   ├── thermostat.h
│   │   │   ├── ui.c                  # UI-Komponenten
│   │   │   └── config.json           # App-Konfiguration
│   │   ├── light_controller/
│   │   │   ├── light_controller.c
│   │   │   └── ...
│   │   ├── weather/
│   │   ├── mood_light/
│   │   ├── smart_lock/
│   │   ├── scene_trigger/
│   │   ├── energy_monitor/
│   │   ├── media_remote/
│   │   └── doorbell_monitor/
│   │
│   ├── sector_b/                     # Desktop & Workflow
│   │   ├── performance_hud/
│   │   ├── macro_pad/
│   │   ├── pomodoro/
│   │   ├── stock_ticker/
│   │   ├── meeting_status/
│   │   ├── git_tracker/
│   │   └── clipboard_manager/
│   │
│   ├── sector_c/                     # Industrial & Professional
│   │   ├── wifi_analyzer/            # ← DEIN PRODUKT
│   │   │   ├── wifi_analyzer.c
│   │   │   ├── wifi_analyzer.h
│   │   │   ├── ui.c
│   │   │   ├── spectrum.c            # Spektrum-Analyse
│   │   │   └── config.json
│   │   ├── 3d_printer_monitor/
│   │   ├── digital_caliper/
│   │   ├── lab_power_supply/
│   │   └── digital_level/
│   │
│   ├── sector_d/                     # Automotive & Mobility
│   │   ├── obd2_dashboard/
│   │   ├── ebike_computer/
│   │   ├── sim_racing_box/
│   │   └── compass/
│   │
│   ├── sector_e/                     # Lifestyle & Gadgets
│   │   ├── cyberpunk_watch/
│   │   ├── tamagotchi/
│   │   ├── digital_dice/
│   │   ├── cocktail_guide/
│   │   └── fitness_coach/
│   │
│   └── sector_f/                     # Security & Tools
│       ├── 2fa_token/
│       ├── hardware_key/
│       ├── nfc_reader/
│       └── midi_xy_pad/
│
├── products/                         # Produktkonfigurationen
│   ├── product_schema.json           # JSON-Schema für Produkte
│   ├── product_builder.py            # Build-System
│   ├── config_validator.py           # Validierung
│   ├── flash_manager.py              # Flashing-Tool
│   │
│   ├── wifi_analyzer/
│   │   ├── config.json               # Produktkonfiguration
│   │   ├── theme.c                   # Produktspezifisches Theme
│   │   ├── firmware_build.cmake      # Build-Konfiguration
│   │   ├── README.md                 # Produktdokumentation
│   │   ├── test_suite.py             # Automatisierte Tests
│   │   └── version.h                 # Produktversion
│   │
│   ├── thermostat/
│   │   ├── config.json
│   │   ├── theme.c
│   │   └── ...
│   │
│   ├── fitness_coach/
│   │   ├── config.json
│   │   └── ...
│   │
│   └── [weitere Produkte]/
│
├── assets/                           # Gemeinsame Assets
│   ├── fonts/
│   │   ├── roboto_12.ttf
│   │   ├── roboto_16.ttf
│   │   └── icons_24.ttf
│   ├── images/
│   │   ├── logo.png
│   │   └── [weitere Bilder]
│   └── themes/
│       ├── color_palettes.json
│       └── animation_presets.json
│
├── CMakeLists.txt                    # Haupt-Build-Datei
├── main.c                            # Einstiegspunkt
├── main.h
├── config.h                          # Globale Konfiguration
│
└── docs/
    ├── ARCHITECTURE.md               # Architektur-Dokumentation
    ├── APP_DEVELOPMENT.md            # App-Entwicklungs-Guide
    ├── PRODUCT_CREATION.md           # Produkt-Erstellungs-Guide
    ├── BUILD_SYSTEM.md               # Build-System-Dokumentation
    └── API_REFERENCE.md              # API-Referenz
```

---

## 🔧 PRODUKTKONFIGURATION (config.json)

```json
{
  "product": {
    "name": "WiFi Analyzer",
    "version": "1.0.0",
    "description": "Professional WiFi Spectrum Analyzer",
    "sector": "c",
    "sku": "CHA-WIFI-001"
  },
  
  "firmware": {
    "primary_app": "wifi_analyzer",
    "secondary_apps": [],
    "theme": "industrial_blue",
    "optimization": "performance"
  },
  
  "hardware": {
    "display": {
      "type": "st7789",
      "width": 172,
      "height": 320,
      "fps": 60
    },
    "touch": {
      "type": "cst816s",
      "enabled": true,
      "calibration": "auto"
    },
    "storage": {
      "flash": 16,
      "psram": 8,
      "sd_card": true
    },
    "connectivity": {
      "wifi": true,
      "ble": false,
      "nfc": false
    },
    "sensors": [
      "wifi_antenna"
    ]
  },
  
  "features": {
    "ui": [
      "spectrum_graph",
      "signal_strength_meter",
      "channel_analyzer",
      "network_list"
    ],
    "api_integrations": [
      "ntp",
      "public_wifi_database"
    ],
    "storage_features": [
      "scan_history",
      "export_csv"
    ]
  },
  
  "build_options": {
    "include_lvgl": true,
    "include_wifi": true,
    "include_ntp": true,
    "include_ota": true,
    "debug_mode": false,
    "optimize_for": "size"
  },
  
  "testing": {
    "auto_test": true,
    "performance_baseline": {
      "fps": 60,
      "ram_usage_max": "4.5MB",
      "flash_usage_max": "1.5MB"
    }
  }
}
```

---

## 🤖 BUILD-SYSTEM (product_builder.py)

```python
#!/usr/bin/env python3
"""
Chameleon OS Product Builder
Automatisiert die Erstellung von Produktfirmware
"""

import json
import subprocess
import os
from pathlib import Path

class ProductBuilder:
    def __init__(self, product_name, port):
        self.product_name = product_name
        self.port = port
        self.config = self.load_config()
        
    def load_config(self):
        """Lade Produktkonfiguration"""
        config_path = f"products/{self.product_name}/config.json"
        with open(config_path, 'r') as f:
            return json.load(f)
    
    def validate_config(self):
        """Validiere Konfiguration gegen Schema"""
        print(f"✓ Validiere Konfiguration für {self.product_name}")
        # Validierungslogik
        
    def generate_cmake(self):
        """Generiere CMakeLists.txt basierend auf Konfiguration"""
        print(f"✓ Generiere CMake-Konfiguration")
        # CMake-Generierung
        
    def compile(self):
        """Kompiliere Firmware"""
        print(f"✓ Kompiliere Firmware")
        result = subprocess.run(
            ["idf.py", "build"],
            cwd=".",
            capture_output=True
        )
        if result.returncode != 0:
            raise Exception(f"Build fehlgeschlagen: {result.stderr}")
    
    def flash(self):
        """Flashe zum Gerät"""
        print(f"✓ Flashe zu {self.port}")
        result = subprocess.run(
            ["idf.py", "-p", self.port, "flash"],
            cwd=".",
            capture_output=True
        )
        if result.returncode != 0:
            raise Exception(f"Flash fehlgeschlagen: {result.stderr}")
    
    def test(self):
        """Teste Firmware"""
        print(f"✓ Teste Firmware")
        # Automatisierte Tests
        # - Display-Test
        # - Touch-Test
        # - App-Funktionalität
        # - Performance-Messung
        
    def build(self):
        """Hauptbuild-Prozess"""
        print(f"\n🚀 Baue {self.product_name} Firmware\n")
        
        try:
            self.validate_config()
            self.generate_cmake()
            self.compile()
            self.flash()
            self.test()
            
            print(f"\n✅ {self.product_name} erfolgreich erstellt und geflasht!")
            print(f"   Firmware-Größe: {self.get_firmware_size()}")
            print(f"   RAM-Nutzung: {self.get_ram_usage()}")
            
        except Exception as e:
            print(f"\n❌ Fehler: {e}")
            return False
        
        return True

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 3:
        print("Verwendung: product_builder.py <product> <port>")
        print("Beispiel: product_builder.py wifi_analyzer /dev/ttyUSB0")
        sys.exit(1)
    
    product = sys.argv[1]
    port = sys.argv[2]
    
    builder = ProductBuilder(product, port)
    success = builder.build()
    sys.exit(0 if success else 1)
```

**Verwendung:**
```bash
python3 product_builder.py wifi_analyzer /dev/ttyUSB0
```

---

## 📦 APP-ENTWICKLUNGS-TEMPLATE

Jede App folgt diesem Template:

```c
// apps/sector_c/wifi_analyzer/wifi_analyzer.c

#include "app_interface.h"
#include "lvgl.h"

// ============ APP STATE ============
typedef struct {
    bool is_scanning;
    int network_count;
    // App-spezifische Daten
} wifi_analyzer_state_t;

static wifi_analyzer_state_t state = {0};

// ============ LIFECYCLE ============
void wifi_analyzer_init(void) {
    printf("[WiFi Analyzer] Initialisierung\n");
    state.is_scanning = false;
    state.network_count = 0;
}

void wifi_analyzer_deinit(void) {
    printf("[WiFi Analyzer] Deinitialisierung\n");
}

void wifi_analyzer_start(void) {
    printf("[WiFi Analyzer] Start\n");
    // Starte WiFi-Scan
}

void wifi_analyzer_stop(void) {
    printf("[WiFi Analyzer] Stop\n");
    // Stoppe WiFi-Scan
}

// ============ RENDERING ============
void wifi_analyzer_render(void) {
    // Zeichne UI
}

void wifi_analyzer_update(void) {
    // Update Daten
}

// ============ INTERACTION ============
void wifi_analyzer_on_touch(touch_event_t event) {
    // Handle Touch-Events
}

void wifi_analyzer_on_button(button_event_t event) {
    // Handle Button-Events
}

// ============ CONFIGURATION ============
void wifi_analyzer_configure(config_t* config) {
    // Konfiguriere App
}

config_t* wifi_analyzer_get_config(void) {
    // Gib Konfiguration zurück
    return NULL;
}

// ============ METADATA ============
const char* wifi_analyzer_get_icon(void) {
    return "📡";
}

const char* wifi_analyzer_get_description(void) {
    return "Professional WiFi Spectrum Analyzer";
}

// ============ APP REGISTRATION ============
const app_t wifi_analyzer_app = {
    .app_name = "WiFi Analyzer",
    .app_version = "1.0.0",
    .sector = "c",
    
    .app_init = wifi_analyzer_init,
    .app_deinit = wifi_analyzer_deinit,
    .app_start = wifi_analyzer_start,
    .app_stop = wifi_analyzer_stop,
    
    .app_render = wifi_analyzer_render,
    .app_update = wifi_analyzer_update,
    
    .app_on_touch = wifi_analyzer_on_touch,
    .app_on_button = wifi_analyzer_on_button,
    
    .app_configure = wifi_analyzer_configure,
    .app_get_config = wifi_analyzer_get_config,
    
    .app_get_icon = wifi_analyzer_get_icon,
    .app_get_description = wifi_analyzer_get_description,
};
```

---

## 🔄 PRODUKTIONS-WORKFLOW (Schritt-für-Schritt)

### Schritt 1: Bestellung kommt rein
```
Kunde: "Wir brauchen 100 WiFi Analyzer Geräte"
```

### Schritt 2: Vorkonfigurierter ESP32-S3 anschließen
```
Hardware: ESP32-S3 mit Chameleon OS Basis
Verbindung: USB-C zum Produktions-PC
Status: Bereit für Konfiguration
```

### Schritt 3: Agent wird aufgerufen
```bash
python3 products/product_builder.py wifi_analyzer /dev/ttyUSB0
```

### Schritt 4: Agent führt aus
```
1. Lade products/wifi_analyzer/config.json
2. Validiere Konfiguration
3. Generiere CMakeLists.txt
4. Kompiliere Firmware (~30 Sekunden)
5. Flashe zum Gerät (~10 Sekunden)
6. Teste Funktionalität (~5 Sekunden)
7. Gib Erfolg zurück
```

### Schritt 5: Gerät ist produktionsreif
```
✅ Firmware erfolgreich geflasht
✅ Display zeigt WiFi Analyzer Interface
✅ Touch funktioniert
✅ WiFi-Scan funktioniert
✅ Performance: 60 FPS
✅ RAM-Nutzung: 3.5 MB / 8 MB
✅ Flash-Nutzung: 1.2 MB / 16 MB

→ Verbauen in Gehäuse, fertig!
```

---

## 🎯 KRITISCHE IMPLEMENTIERUNGS-PUNKTE

### 1. App-Isolation
- Apps dürfen nicht direkt auf andere Apps zugreifen
- Kommunikation nur über standardisierte APIs
- Jede App hat eigenen Memory-Space

### 2. Theme-System
- Zentrale Farbpaletten-Verwaltung
- Alle Apps müssen Theme-kompatibel sein
- Theme-Wechsel zur Laufzeit ohne Neustart

### 3. Performance-Constraints
- Jede App muss 60 FPS halten
- RAM-Limit: ~4.5 MB (von 8 MB PSRAM)
- Flash-Limit: ~1.5 MB pro App

### 4. Build-Optimierung
- Nur nötige Komponenten kompilieren
- Aggressive Optimierung für Größe
- Stripping von Debug-Symbolen

---

## ✅ ZUSAMMENFASSUNG

Die Architektur ermöglicht:
- ✅ Schnelle Produkterstellung (< 1 Minute pro Gerät)
- ✅ Modulare App-Entwicklung
- ✅ Zentrale Theme-Verwaltung
- ✅ Automatisierte Tests
- ✅ Skalierbarkeit auf 33+ Apps
- ✅ Zukünftige Erweiterbarkeit
