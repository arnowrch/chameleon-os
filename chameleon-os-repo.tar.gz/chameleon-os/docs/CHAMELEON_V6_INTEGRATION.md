# 🦎 CHAMELEON OS: Integration von Demo V6

> **Status**: Demo V6 ist GOLD ✅  
> **Aktion**: Alle funktionierenden Komponenten in Chameleon OS Blueprint integrieren  
> **Ergebnis**: Produktionsreifer Code, nicht von Grund auf neu schreiben

---

## 🎯 SITUATION

### Was wir haben:
- ✅ **Demo V6**: Funktionierendes Projekt (Build, Flash, Boot erfolgreich)
- ✅ **Getestete Komponenten**: Display, Touch, WiFi, NTP, IMU, Battery, SD Card
- ✅ **Bewährte Struktur**: BSP (Board Support Package) + Components
- ✅ **Lessons Learned**: Dokumentiert, validiert, integriert

### Was wir brauchen:
- ✅ **Chameleon OS Blueprint**: Architektur, Framework, Apps
- ✅ **PlatformIO Migration**: Von ESP-IDF zu PlatformIO
- ✅ **Event Bus & Theme Manager**: Neue Framework-Layer
- ✅ **33 Apps**: Dummy → Funktionsfähig → Abgelegt

---

## 🔄 INTEGRATIONS-STRATEGIE

### Phase 1: Code-Übernahme (NICHT neu schreiben!)

**Aus Demo V6 direkt übernehmen:**

| Komponente | Status | Action |
|-----------|--------|--------|
| `bsp_display.c/h` | ✅ Funktioniert | Direkt kopieren → `core/hal/display.c` |
| `bsp_touch.c/h` | ✅ Funktioniert | Direkt kopieren → `core/hal/touch.c` |
| `bsp_i2c.c/h` | ✅ Funktioniert | Direkt kopieren → `core/hal/i2c.c` |
| `bsp_wifi.c/h` | ✅ Funktioniert | Direkt kopieren → `core/hal/wifi.c` |
| `bsp_qmi8658.c/h` | ⚠️ Optional | Kopieren, aber fehlertoleranter Init |
| `bsp_battery.c/h` | ✅ Funktioniert | Kopieren (für Zukunft) |
| `bsp_sdcard.c/h` | ✅ Funktioniert | Kopieren (für Zukunft) |
| `ui_theme.h` | ✅ Gut | Erweitern → Theme Manager |
| `main.c` | ⚠️ Umstrukturieren | Golden Path Initialisierung |

### Phase 2: PlatformIO Migration

**Umwandlung von ESP-IDF zu PlatformIO:**

```
ESP-IDF Struktur:
├── components/
├── main/
├── CMakeLists.txt
└── sdkconfig

↓ Wird zu ↓

PlatformIO Struktur:
├── src/
│   ├── main.c
│   ├── hal/
│   ├── framework/
│   └── apps/
├── lib/
│   ├── esp_bsp/
│   ├── esp_lcd_jd9853/
│   └── esp_lcd_touch_axs5106/
├── platformio.ini
└── .gitignore
```

### Phase 3: Framework-Layer hinzufügen

**Neue Komponenten (nicht in Demo V6):**
- Event Bus (zentrale Event-Verwaltung)
- Theme Manager (erweiterte Farb-Verwaltung)
- Carousel Navigation (App-Menü)
- Gesture Recognition (Swipe, Long-Press)

### Phase 4: Apps entwickeln

**Iterativ, mit Demo V6 als Basis:**
- Weather Crystal (Dummy → Funktionsfähig)
- WiFi Analyzer (Dummy → Funktionsfähig)
- Pomodoro Timer (Dummy → Funktionsfähig)
- ... (weitere 30 Apps)

---

## 📋 KONKRETE INTEGRATIONS-SCHRITTE

### Schritt 1: Demo V6 Code-Übernahme

**Quelle**: `11_functional_v6/components/esp_bsp/`  
**Ziel**: `chameleon-os/lib/esp_bsp/`

```bash
# 1. Verzeichnis kopieren
cp -r 11_functional_v6/components/esp_bsp chameleon-os/lib/

# 2. Dateien überprüfen
ls -la chameleon-os/lib/esp_bsp/
# Sollte enthalten:
# - bsp_display.c/h
# - bsp_touch.c/h
# - bsp_i2c.c/h
# - bsp_wifi.c/h
# - bsp_qmi8658.c/h
# - bsp_battery.c/h
# - bsp_sdcard.c/h
```

### Schritt 2: Display-Treiber kopieren

**Quelle**: `11_functional_v6/components/esp_lcd_jd9853/`  
**Ziel**: `chameleon-os/lib/esp_lcd_jd9853/`

```bash
cp -r 11_functional_v6/components/esp_lcd_jd9853 chameleon-os/lib/
```

### Schritt 3: Touch-Treiber kopieren

**Quelle**: `11_functional_v6/components/esp_lcd_touch_axs5106/`  
**Ziel**: `chameleon-os/lib/esp_lcd_touch_axs5106/`

```bash
cp -r 11_functional_v6/components/esp_lcd_touch_axs5106 chameleon-os/lib/
```

### Schritt 4: HAL-Wrapper erstellen

**Datei**: `src/hal/hal.c` (Wrapper um Demo V6 Code)

```c
// ============================================
// CHAMELEON OS: HAL Wrapper
// Wrapper um Demo V6 BSP-Code
// ============================================

#include "hal.h"
#include "bsp_display.h"
#include "bsp_touch.h"
#include "bsp_i2c.h"
#include "bsp_wifi.h"
#include "bsp_qmi8658.h"
#include "bsp_battery.h"

// Hardware Status (aus Validierung)
hardware_status_t hw_status = {0};

// === INITIALISIERUNGS-REIHENFOLGE (Golden Path) ===
esp_err_t hal_init_all(void) {
    ESP_LOGI(TAG, "\n=== HAL Initialization (Golden Path) ===\n");
    
    // 1. NVS (in main.c)
    
    // 2. I2C Bus
    i2c_master_bus_handle_t i2c_bus = bsp_i2c_init();
    if (i2c_bus == NULL) {
        ESP_LOGE(TAG, "I2C init failed!");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "✓ I2C initialized");
    
    // 3. IMU (optional, fehlertoleranter Init)
    esp_err_t imu_ret = bsp_qmi8658_init(i2c_bus);
    if (imu_ret != ESP_OK) {
        ESP_LOGW(TAG, "QMI8658 init failed, continuing without IMU");
        hw_status.imu_ok = false;
    } else {
        hw_status.imu_ok = true;
        ESP_LOGI(TAG, "✓ IMU initialized");
    }
    
    // 4. Battery ADC
    bsp_battery_init();
    ESP_LOGI(TAG, "✓ Battery ADC initialized");
    
    // 5. WiFi (MUSS vor Display sein!)
    esp_err_t wifi_ret = bsp_wifi_init(WIFI_SSID, WIFI_PASS);
    if (wifi_ret != ESP_OK) {
        ESP_LOGW(TAG, "WiFi init failed, continuing without WiFi");
        hw_status.wifi_ok = false;
    } else {
        hw_status.wifi_ok = true;
        ESP_LOGI(TAG, "✓ WiFi initialized");
    }
    
    // 6. Display (KRITISCH!)
    esp_lcd_panel_io_handle_t io_handle = NULL;
    esp_lcd_panel_handle_t panel_handle = NULL;
    esp_err_t disp_ret = bsp_display_init(&io_handle, &panel_handle, 
                                          320 * 50);  // Buffer size
    if (disp_ret != ESP_OK) {
        ESP_LOGE(TAG, "Display init failed!");
        return ESP_FAIL;
    }
    hw_status.display_ok = true;
    ESP_LOGI(TAG, "✓ Display initialized (320×172, rotation 90°)");
    
    // 7. Touch (KRITISCH!)
    esp_lcd_touch_handle_t touch_handle = NULL;
    esp_err_t touch_ret = bsp_touch_init(&touch_handle, i2c_bus, 320, 172, 90);
    if (touch_ret != ESP_OK) {
        ESP_LOGE(TAG, "Touch init failed!");
        return ESP_FAIL;
    }
    hw_status.touch_ok = true;
    ESP_LOGI(TAG, "✓ Touch initialized");
    
    // 8. SD Card (optional)
    esp_err_t sd_ret = bsp_sdcard_init();
    if (sd_ret != ESP_OK) {
        ESP_LOGW(TAG, "SD Card init failed, continuing without SD");
    } else {
        ESP_LOGI(TAG, "✓ SD Card initialized");
    }
    
    ESP_LOGI(TAG, "\n✅ HAL initialization complete!\n");
    return ESP_OK;
}

// === EINZELNE KOMPONENTEN ===
esp_err_t display_check(void) {
    return hw_status.display_ok ? ESP_OK : ESP_FAIL;
}

esp_err_t touch_check(void) {
    return hw_status.touch_ok ? ESP_OK : ESP_FAIL;
}

esp_err_t wifi_check(void) {
    return hw_status.wifi_ok ? ESP_OK : ESP_FAIL;
}

esp_err_t ntp_check(void) {
    // TODO: Implementieren
    return ESP_OK;
}
```

### Schritt 5: platformio.ini erstellen

**Datei**: `platformio.ini`

```ini
[env:chameleon-os]
platform = espressif32
board = esp32-s3-devkitc-1
framework = arduino

# === BUILD FLAGS ===
build_flags = 
    -DCONFIG_SPIRAM=y
    -DCONFIG_SPIRAM_MODE_QUAD=y
    -DCONFIG_SPIRAM_SPEED_80M=y
    -O3
    -march=xtensa-lx7
    -mtune=xtensa-lx7

# === LIBRARIES ===
lib_deps = 
    lvgl/lvgl @ ^9.0.0
    espressif/esp-idf-cxx @ ^1.0.0
    espressif/esp_lcd_touch @ ^1.1.2
    espressif/button @ ^3.3.1

# === LIBRARY PATHS ===
lib_extra_dirs = lib/

# === MONITOR ===
monitor_speed = 115200
monitor_filters = esp32_exception_decoder

# === UPLOAD ===
upload_speed = 460800
```

### Schritt 6: main.c mit Golden Path

**Datei**: `src/main.c`

```c
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "hal.h"
#include "framework/event_bus.h"
#include "framework/theme_manager.h"
#include "framework/carousel.h"
#include "startup_validator.h"

static const char *TAG = "CHAMELEON_OS";

void app_main(void) {
    ESP_LOGI(TAG, "\n\n=== CHAMELEON OS Boot ===\n");
    
    // 1. NVS (Non-Volatile Storage)
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    ESP_LOGI(TAG, "✓ NVS initialized");
    
    // 2-8. HAL (alle Komponenten)
    ESP_ERROR_CHECK(hal_init_all());
    
    // 9. LVGL (wird in bsp_display_init aufgerufen)
    ESP_LOGI(TAG, "✓ LVGL initialized");
    
    // 10. Event Bus
    event_bus_init();
    ESP_LOGI(TAG, "✓ Event bus initialized");
    
    // 11. Theme Manager
    theme_init();
    ESP_LOGI(TAG, "✓ Theme manager initialized");
    
    // 12. Startup Validation
    startup_validate();
    
    // 13. UI
    ui_init();
    ESP_LOGI(TAG, "✓ UI initialized");
    
    // 14. Carousel (App-Menü)
    carousel_start();
    ESP_LOGI(TAG, "✓ Carousel started");
    
    ESP_LOGI(TAG, "\n✅ Boot complete! System ready.\n");
}
```

---

## 📊 KONKRETE DATEIEN AUS DEMO V6

### Zu kopierende Dateien

```
11_functional_v6/components/esp_bsp/
├── bsp_display.c        → lib/esp_bsp/bsp_display.c
├── bsp_display.h        → lib/esp_bsp/bsp_display.h
├── bsp_touch.c          → lib/esp_bsp/bsp_touch.c
├── bsp_touch.h          → lib/esp_bsp/bsp_touch.h
├── bsp_i2c.c            → lib/esp_bsp/bsp_i2c.c
├── bsp_i2c.h            → lib/esp_bsp/bsp_i2c.h
├── bsp_wifi.c           → lib/esp_bsp/bsp_wifi.c
├── bsp_wifi.h           → lib/esp_bsp/bsp_wifi.h
├── bsp_qmi8658.c        → lib/esp_bsp/bsp_qmi8658.c
├── bsp_qmi8658.h        → lib/esp_bsp/bsp_qmi8658.h
├── bsp_battery.c        → lib/esp_bsp/bsp_battery.c
├── bsp_battery.h        → lib/esp_bsp/bsp_battery.h
├── bsp_sdcard.c         → lib/esp_bsp/bsp_sdcard.c
└── bsp_sdcard.h         → lib/esp_bsp/bsp_sdcard.h

11_functional_v6/components/esp_lcd_jd9853/
└── *                    → lib/esp_lcd_jd9853/

11_functional_v6/components/esp_lcd_touch_axs5106/
└── *                    → lib/esp_lcd_touch_axs5106/

11_functional_v6/main/
├── ui_theme.h           → src/ui/theme/ui_theme.h (erweitern)
├── wifi_credentials.h   → src/wifi_credentials.h (git-ignored)
└── screen_showcase_v2.c → (als Referenz für erste App)
```

### Zu modifizierende Dateien

```
Demo V6:                              Chameleon OS:
main/main.c                    →      src/main.c (mit Golden Path)
main/ui_theme.h                →      src/ui/theme/theme_manager.c (erweitern)
CMakeLists.txt                 →      platformio.ini (neue Build-Config)
sdkconfig                      →      platformio.ini (Konfiguration)
```

---

## ✅ INTEGRATIONS-CHECKLISTE

### Code-Übernahme
- [ ] `lib/esp_bsp/` kopiert (alle BSP-Dateien)
- [ ] `lib/esp_lcd_jd9853/` kopiert
- [ ] `lib/esp_lcd_touch_axs5106/` kopiert
- [ ] Alle Dateien kompilieren (keine Fehler)

### HAL-Wrapper
- [ ] `src/hal/hal.c` erstellt (Wrapper um BSP)
- [ ] `src/hal/hal.h` erstellt (Interface)
- [ ] Golden Path Initialisierung funktioniert
- [ ] Hardware Status Tracking funktioniert

### PlatformIO Migration
- [ ] `platformio.ini` erstellt
- [ ] `src/main.c` mit Golden Path
- [ ] Erste Build erfolgreich: `pio run`
- [ ] Erste Flash erfolgreich: `pio run -t upload`
- [ ] Monitor zeigt Boot-Meldungen: `pio run -t monitor`

### Framework-Layer
- [ ] Event Bus implementiert
- [ ] Theme Manager implementiert
- [ ] Carousel Navigation implementiert
- [ ] Gesture Recognition implementiert

### Erste App
- [ ] Weather Crystal (Dummy) erstellt
- [ ] Carousel kann App laden
- [ ] App reagiert auf Touch

---

## 🎯 ERGEBNIS

**Nach dieser Integration:**

✅ Chameleon OS basiert auf bewährtem, getestem Code (Demo V6)  
✅ Nicht von Grund auf neu schreiben (Fehler vermeiden)  
✅ PlatformIO Build-System (einfacher als ESP-IDF)  
✅ Golden Path Initialisierung (strukturiert)  
✅ Framework-Layer (Event Bus, Theme Manager)  
✅ Bereit für 33 Apps (Dummy → Funktionsfähig)

---

## 🚀 NÄCHSTE SCHRITTE

1. **Für VS Code Agent**:
   - Lese dieses Dokument
   - Kopiere Demo V6 Code (siehe Checkliste)
   - Erstelle HAL-Wrapper
   - Migriere zu PlatformIO
   - Teste erste Build & Flash

2. **Für dich**:
   - Bestätige: Sollen wir Demo V6 Code direkt übernehmen?
   - Bestätige: PlatformIO als Build-System?
   - Bestätige: Erste 3 Apps (Weather, WiFi, Pomodoro)?

---

**Chameleon OS: Auf Basis von bewährtem Code, mit neuer Architektur. 🦎**
