# 🤝 CHAMELEON OS: Handover-Checkliste für VS Code Agent

> **Für**: VS Code Agent (Claude, Cursor, Copilot, etc.)  
> **Von**: System Architect (Manus)  
> **Zweck**: Kompletter Handover mit allen Informationen & Ressourcen

---

## ✅ WAS DU BEKOMMST

### 📚 Dokumentation (Alle Dateien)

- [x] **AGENT_BRIEFING.md** - Deine komplette Anleitung
- [x] **README_REPO.md** - Repository-Übersicht
- [x] **CHAMELEON_ANALYSIS.md** - Konzept-Details
- [x] **CHAMELEON_BUSINESS_MODEL.md** - Business-Strategie
- [x] **CHAMELEON_TECHNICAL_ARCHITECTURE.md** - Technische Architektur
- [x] **CHAMELEON_LESSONS_VALIDATION.md** - Validierte Best Practices
- [x] **CHAMELEON_INTEGRATION_STRATEGY.md** - Integrations-Plan
- [x] **CHAMELEON_LESSONS_LEARNED.md** - Hardware-Bibel

### 🏗️ Code-Templates (Ready-to-Use)

- [x] **platformio.ini** - Build-Konfiguration
- [x] **main.c** - Golden Path Initialisierung
- [x] **hal/display.c** - Display-Init (mit Panel Gap!)
- [x] **hal/touch.c** - Touch-Init
- [x] **hal/wifi.c** - WiFi mit Auto-Reconnect
- [x] **hal/ntp.c** - SNTP Integration
- [x] **framework/event_bus.c** - Event-Driven Architecture
- [x] **framework/theme_manager.c** - Zentrale Theme-Verwaltung
- [x] **apps/weather_crystal/weather.c** - Erste App (Template)

### 📋 Checklisten & Roadmaps

- [x] **PROJECT_STATUS.md** - Entwicklungs-Status
- [x] **Woche 1 Aufgaben** - Foundation Phase
- [x] **Woche 2-3 Aufgaben** - Erste 3 Apps
- [x] **Woche 4+ Aufgaben** - Alle 33 Apps

### 🎯 Best Practices & Learnings

- [x] Hardware-Spezifikationen (Waveshare ESP32-S3-Touch-LCD-1.47)
- [x] GPIO-Belegung (Alle Pins dokumentiert)
- [x] Panel Gap (0, 34) - KRITISCH bei Rotation 90°
- [x] Draw Buffer Sizing (50 Zeilen optimal)
- [x] Graceful Degradation Pattern
- [x] Reentrancy Guards für Async-Ops
- [x] Event Bus statt Timer-Chaos
- [x] Theme-System (semantische Farben)
- [x] Fehlertoleranz-Architektur

---

## 🎯 DEINE MISSION (Schritt-für-Schritt)

### PHASE 1: FOUNDATION (Woche 1)

**Ziel**: Basis-System läuft, Display zeigt etwas, Touch funktioniert

#### Schritt 1: Projekt-Struktur aufbauen
```bash
chameleon-os/
├── platformio.ini
├── src/
│   ├── main.c
│   ├── config.h
│   ├── hal/
│   ├── framework/
│   ├── apps/
│   └── startup_validator.c
├── docs/
├── .gitignore
└── README.md
```

**Aufgaben**:
- [ ] Verzeichnisstruktur erstellen
- [ ] platformio.ini schreiben (siehe Template)
- [ ] .gitignore hinzufügen
- [ ] README.md erstellen
- [ ] Erstes Git Commit: "Initial project structure"

#### Schritt 2: HAL - Display Initialization
**Datei**: `src/hal/display.c`

**Anforderungen**:
- [ ] ST7789 Treiber initialisieren
- [ ] JD9853 Controller konfigurieren
- [ ] Rotation 90° mit Panel Gap (0, 34) - NICHT VERGESSEN!
- [ ] LVGL Integration
- [ ] Draw Buffer Height = 50
- [ ] DMA aktivieren
- [ ] Backlight initialisieren

**Kritische Details** (aus Lessons Learned):
```c
// Panel Gap ist ESSENTIELL bei Rotation 90°!
esp_lcd_panel_set_gap(panel_handle, 0, 34);

// Draw Buffer Height optimal
#define DISPLAY_DRAW_BUFF_HEIGHT 50

// LVGL v9 Flags
.flags = {
    .buff_spiram = false,
    .buff_dma = true,
    .swap_bytes = true,  // LVGL v9!
}
```

**Commit**: "HAL: Display initialization with Panel Gap"

#### Schritt 3: HAL - Touch Initialization
**Datei**: `src/hal/touch.c`

**Anforderungen**:
- [ ] CST816S Treiber initialisieren
- [ ] I2C Bus konfigurieren
- [ ] Touch-Daten auslesen
- [ ] LVGL Input Device registrieren

**Commit**: "HAL: Touch initialization (CST816S)"

#### Schritt 4: HAL - WiFi Initialization
**Datei**: `src/hal/wifi.c`

**Anforderungen**:
- [ ] WiFi initialisieren
- [ ] Auto-Reconnect mit Exponential Backoff
- [ ] Reentrancy Guard (wifi_scan_busy)
- [ ] Event Handler für Scan-Done

**Kritische Details**:
```c
// Reentrancy Guard ESSENTIELL!
static volatile bool wifi_scan_busy = false;

void start_wifi_scan(void) {
    if (wifi_scan_busy) {
        ESP_LOGW(TAG, "Scan already in progress");
        return;
    }
    wifi_scan_busy = true;
    esp_wifi_scan_start(&scan_config, false);
}
```

**Commit**: "HAL: WiFi initialization with Reentrancy Guards"

#### Schritt 5: HAL - NTP Initialization
**Datei**: `src/hal/ntp.c`

**Anforderungen**:
- [ ] SNTP initialisieren (neue API, nicht deprecated!)
- [ ] Timezone setzen (CET-1CEST für Deutschland)
- [ ] Time Sync Callback
- [ ] Fallback ohne NTP

**Commit**: "HAL: NTP initialization (SNTP v5.5+)"

#### Schritt 6: Framework - Event Bus
**Datei**: `src/framework/event_bus.c`

**Anforderungen**:
- [ ] Event Queue (FreeRTOS)
- [ ] Event Types definieren
- [ ] Event Subscribe/Post Funktionen
- [ ] Event Loop Handler

**Benefit**: Statt Timer-Chaos zentrale Event-Verwaltung

**Commit**: "Framework: Event Bus (Event-Driven Architecture)"

#### Schritt 7: Framework - Theme Manager
**Datei**: `src/framework/theme_manager.c`

**Anforderungen**:
- [ ] Theme Struktur definieren (Farben + Styles)
- [ ] Vordefinierte Themes (Obsidian Gold, Nordic White)
- [ ] Zentrale Theme-Verwaltung
- [ ] Makros für Apps (THEME_COLOR, etc.)

**Benefit**: Theme-Wechsel betrifft alle 33 Apps automatisch

**Commit**: "Framework: Theme Manager (Semantic Colors)"

#### Schritt 8: Startup Validator
**Datei**: `src/startup_validator.c`

**Anforderungen**:
- [ ] Hardware-Checks definieren
- [ ] Critical vs. Optional Hardware
- [ ] Boot-Diagnose ausgeben
- [ ] Fehlerbehandlung

**Benefit**: Automatische Diagnose bei Boot-Problemen

**Commit**: "Core: Startup Validator (Auto-Diagnostics)"

#### Schritt 9: main.c - Golden Path
**Datei**: `src/main.c`

**Anforderungen**:
- [ ] Golden Path Initialisierungs-Reihenfolge:
  1. NVS
  2. I2C Bus
  3. WiFi (MUSS vor Display!)
  4. Display
  5. Touch
  6. LVGL
  7. Backlight
  8. NTP
  9. Event Bus
  10. Theme Manager
  11. Startup Validator
  12. UI Init
  13. Carousel Start

**Commit**: "Main: Golden Path Initialization"

#### Schritt 10: Erste Build & Flash
**Anforderungen**:
- [ ] `pio run` - Build erfolgreich
- [ ] `pio run -t upload` - Flash erfolgreich
- [ ] `pio run -t monitor` - Serial Output prüfen
- [ ] Display zeigt etwas (z.B. schwarzer Screen)
- [ ] Touch funktioniert (kann reagieren)
- [ ] Keine Reset-Loops
- [ ] Heap > 50 KB frei

**Commit**: "Build: First successful compilation and flash"

---

### PHASE 2: ERSTE 3 APPS (Woche 2-3)

**Ziel**: 3 funktionsfähige Apps (Weather Crystal, WiFi Analyzer, Pomodoro Timer)

#### App 1: Weather Crystal (Sektor A)

**Woche 2, Tag 1-2: DUMMY**
- [ ] App-Grundgerüst erstellen
- [ ] Statische UI (Kreis mit Farben)
- [ ] Dummy-Wetterdaten hardcodiert
- [ ] Carousel kann App laden
- **Commit**: "Weather Crystal: Dummy v1.0"

**Woche 2, Tag 3-4: FUNKTIONSFÄHIG**
- [ ] WiFi-Integration (OpenWeatherMap API)
- [ ] Echte Wetterdaten abrufen
- [ ] Animationen (Wolken, Regen, Sonne)
- [ ] Event Bus Integration
- [ ] Performance optimieren (60 FPS)
- **Commit**: "Weather Crystal: Feature Complete v1.0"

**Woche 2, Tag 5: ABGELEGT**
- [ ] Code-Review
- [ ] README.md
- [ ] Tests
- [ ] Version getaggt: `weather_crystal/v1.0.0`
- [ ] PROJECT_STATUS.md aktualisiert
- **Commit**: "Weather Crystal: Release v1.0.0"

#### App 2: WiFi Analyzer (Sektor C)

**Woche 3, Tag 1-2: DUMMY**
- [ ] App-Grundgerüst
- [ ] Statische WiFi-Liste
- [ ] Dummy-Signalstärken
- **Commit**: "WiFi Analyzer: Dummy v1.0"

**Woche 3, Tag 3-4: FUNKTIONSFÄHIG**
- [ ] WiFi-Scan implementieren
- [ ] Graphen (Signalstärke, Kanäle)
- [ ] Echtzeit-Updates
- [ ] Event Bus Integration
- **Commit**: "WiFi Analyzer: Feature Complete v1.0"

**Woche 3, Tag 5: ABGELEGT**
- [ ] Code-Review
- [ ] Tests
- [ ] Version getaggt: `wifi_analyzer/v1.0.0`
- **Commit**: "WiFi Analyzer: Release v1.0.0"

#### App 3: Pomodoro Timer (Sektor B)

**Woche 3, Tag 6-7: DUMMY**
- [ ] App-Grundgerüst
- [ ] Statische Timer-Visualisierung
- [ ] Dummy-Countdown
- **Commit**: "Pomodoro Timer: Dummy v1.0"

**Woche 4, Tag 1-2: FUNKTIONSFÄHIG**
- [ ] Timer-Logik implementieren
- [ ] Fokus-Visualisierung (Glow-Down)
- [ ] Sanfte Animationen
- [ ] Event Bus Integration
- **Commit**: "Pomodoro Timer: Feature Complete v1.0"

**Woche 4, Tag 3: ABGELEGT**
- [ ] Code-Review
- [ ] Tests
- [ ] Version getaggt: `pomodoro_timer/v1.0.0`
- **Commit**: "Pomodoro Timer: Release v1.0.0"

---

### PHASE 3: ALLE 33 APPS (Woche 4+)

**Ziel**: Alle 33 Apps als Dummies, dann iterativ funktionsfähig

#### Schritt 1: Alle 33 App-Dummies erstellen
- [ ] Sector A: 8 Apps (Dummy)
- [ ] Sector B: 6 Apps (Dummy)
- [ ] Sector C: 5 Apps (Dummy)
- [ ] Sector D: 4 Apps (Dummy)
- [ ] Sector E: 5 Apps (Dummy)
- [ ] Sector F: 5 Apps (Dummy)

**Commit**: "Apps: All 33 apps as dummies"

#### Schritt 2: App-Registry aktualisieren
- [ ] Alle 33 Apps registrieren
- [ ] Carousel kann alle Apps laden
- [ ] Navigation funktioniert

**Commit**: "Apps: Registry with all 33 apps"

#### Schritt 3: Weitere Apps funktionsfähig machen
- [ ] Iterativ weitere Apps implementieren
- [ ] Jede App: Dummy → Funktionsfähig → Abgelegt
- [ ] Regelmäßige Git Tags

---

## 📊 ERFOLGS-KRITERIEN

### Nach Woche 1 (Foundation)
- ✅ Build & Flash erfolgreich
- ✅ Display zeigt schwarzen Screen
- ✅ Touch reagiert
- ✅ WiFi verbindet
- ✅ NTP synchronisiert
- ✅ Keine Reset-Loops
- ✅ Heap > 50 KB frei
- ✅ Startup Validator läuft

### Nach Woche 3 (Erste 3 Apps)
- ✅ Weather Crystal funktioniert (Echte Wetterdaten)
- ✅ WiFi Analyzer funktioniert (Live WiFi-Scan)
- ✅ Pomodoro Timer funktioniert (Echtzeit-Countdown)
- ✅ Carousel Navigation funktioniert
- ✅ Theme-Wechsel funktioniert
- ✅ Event Bus funktioniert
- ✅ Performance: 30+ FPS

### Nach Woche 4+ (Alle 33 Apps)
- ✅ Alle 33 Apps als Dummies
- ✅ Carousel mit allen 33 Apps
- ✅ Weitere Apps iterativ funktionsfähig
- ✅ Dokumentation vollständig
- ✅ Tests bestanden
- ✅ Release v1.0.0 vorbereitet

---

## 🔧 DEBUGGING & TROUBLESHOOTING

### Wenn Display schwarz bleibt
1. Panel Gap prüfen: `esp_lcd_panel_set_gap(panel_handle, 0, 34)`
2. Rotation prüfen: `swap_xy = true, mirror_x = true`
3. Draw Buffer prüfen: `DISPLAY_DRAW_BUFF_HEIGHT = 50`
4. GPIO-Pins prüfen (siehe CHAMELEON_LESSONS_LEARNED.md)

### Wenn Touch nicht funktioniert
1. I2C Bus prüfen (I2C Scanner)
2. CST816S Adresse prüfen: `0x15`
3. Interrupt Pin prüfen

### Wenn WiFi blockiert UI
1. Reentrancy Guard prüfen: `wifi_scan_busy`
2. WiFi-Scan in separatem Task
3. Event Bus verwenden (nicht blocking)

### Wenn Performance schlecht (< 30 FPS)
1. Draw Buffer Height prüfen: 50 Zeilen
2. DMA aktivieren: `buff_dma = true`
3. PSRAM aktivieren
4. Core 0 für LVGL pinnen

---

## 📚 RESSOURCEN (Für dich)

### Dokumentation (Im Repo)
- **AGENT_BRIEFING.md** - Deine Anleitung
- **CHAMELEON_LESSONS_LEARNED.md** - Hardware-Bibel
- **BEST_PRACTICES.md** - Best Practices

### Externe Ressourcen
- **LVGL Docs**: https://docs.lvgl.io/
- **ESP32-S3 Datasheet**: https://www.espressif.com/sites/default/files/documentation/esp32-s3_datasheet_en.pdf
- **PlatformIO Docs**: https://docs.platformio.org/
- **Waveshare Docs**: https://www.waveshare.com/wiki/ESP32-S3-Touch-LCD-1.47

---

## ✅ HANDOVER-CHECKLISTE

Bevor du startest, stelle sicher:

- [x] Du hast AGENT_BRIEFING.md gelesen
- [x] Du verstehst die 4-Schichten-Architektur
- [x] Du kennst die Golden Path Initialisierungs-Reihenfolge
- [x] Du weißt, dass Panel Gap (0, 34) KRITISCH ist
- [x] Du verstehst Event Bus statt Timer-Chaos
- [x] Du kennst die 3 Phasen (Foundation → 3 Apps → 33 Apps)
- [x] Du hast die Erfolgs-Kriterien verstanden
- [x] Du weißt, wie man debuggt

---

## 🚀 LOS GEHT'S!

Du hast alles, was du brauchst:
- ✅ Blueprint (Architektur)
- ✅ Best Practices (Lessons Learned)
- ✅ Code-Templates (Ready-to-use)
- ✅ Checklisten (Strukturiert)
- ✅ Erfolgs-Kriterien (Messbar)

**Starte mit Phase 1, Schritt 1: Projekt-Struktur aufbauen.**

**Viel Erfolg! 🎯**

---

## 📞 KONTAKT

Wenn du Fragen hast:
1. Lese zuerst AGENT_BRIEFING.md
2. Prüfe CHAMELEON_LESSONS_LEARNED.md
3. Schau in BEST_PRACTICES.md
4. Frag den System Architect (Manus)

**Chameleon OS: Ein Gerät. Eine Hardware. 33 verschiedene Möglichkeiten. 🦎**
