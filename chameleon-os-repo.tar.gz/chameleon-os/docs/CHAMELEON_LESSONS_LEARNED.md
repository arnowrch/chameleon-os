# 🎓 CHAMELEON OS: Lessons Learned & Best Practices

> **Dokumentation für Entwickler und KI-Agenten**  
> Integrierte Erkenntnisse aus dem LVGL-Projekt und ESP32-S3 Entwicklung

---

## 🎯 Zweck dieses Dokuments

Dieses Dokument fasst alle wichtigen Erkenntnisse, Best Practices und häufige Stolpersteine aus der ESP32-S3 Entwicklung zusammen. Es ist speziell für die **Chameleon OS Entwicklung** optimiert und hilft KI-Agenten, effizienter zu arbeiten.

---

## 📌 HARDWARE: Waveshare ESP32-S3-Touch-LCD-1.47

### Spezifikationen (Kritisch!)

| Komponente | Wert | Bemerkung |
|------------|------|----------|
| **MCU** | ESP32-S3 Dual-Core | 240 MHz, nicht ESP32! |
| **RAM** | 8 MB PSRAM | Essentiell für 60 FPS Double Buffering |
| **Flash** | 16 MB | Für Firmware + Assets |
| **Display** | ST7789, 1.47", 172×320px | IPS, 262K Farben |
| **Touch** | CST816S Kapazitiv | I2C-basiert |
| **Connectivity** | WiFi 802.11 b/g/n | 2.4 GHz |
| **Storage** | TF-Card Slot | Für Bilder, Fonts, Assets |

### ⚠️ Häufigste Fehlerquellen

1. **Falsche Pin-Zuordnung**: Alte Beispiele verwenden oft ESP32-Pins, nicht ESP32-S3!
2. **PSRAM nicht aktiviert**: Ohne PSRAM keine 60 FPS möglich
3. **Display-Treiber-Konfiguration**: ST7789 braucht spezifische SPI-DMA-Einstellungen
4. **Touch-Kalibrierung**: CST816S benötigt möglicherweise Kalibrierung pro Gerät

---

## 🔧 BUILD-SYSTEM & TOOLCHAIN

### ESP-IDF Konfiguration (Essentiell)

**Verwende ESP-IDF v5.1+ für beste PSRAM-Unterstützung:**

```bash
# Installation
git clone --recursive https://github.com/espressif/esp-idf.git
cd esp-idf
git checkout release/v5.1
./install.sh
```

**Wichtige Konfigurationen (idf.py menuconfig):**

```
Component config → ESP32-S3 Specific
├── [*] Enable PSRAM
├── [*] Enable PSRAM as main memory
├── PSRAM Clock Speed: 80 MHz
└── PSRAM Chip Selection: Auto-detect

Component config → LVGL
├── [*] Enable LVGL
├── [*] Enable LVGL Demos
├── Display Resolution: 172×320
└── Color Depth: 16-bit (RGB565)

Component config → FreeRTOS
├── Tick Rate: 1000 Hz
└── Task Stack Size: Adequate for UI tasks
```

### CMakeLists.txt Best Practices

```cmake
# Für Chameleon OS
cmake_minimum_required(VERSION 3.5)

project(chameleon-os)

# PSRAM-Optimierung
idf_component_register(
    SRCS "main.c" "hal/display.c" "hal/touch.c" "ui/carousel.c"
    INCLUDE_DIRS "."
    REQUIRES esp_psram lvgl
)

# Compiler-Flags für Performance
target_compile_options(${COMPONENT_LIB} PRIVATE
    -O3                    # Aggressive Optimierung
    -march=xtensa-lx7      # ESP32-S3 spezifisch
    -mtune=xtensa-lx7
)

# PSRAM-Speicher für LVGL
target_link_options(${COMPONENT_LIB} PRIVATE
    -Wl,--wrap=malloc
    -Wl,--wrap=free
)
```

---

## 🖥️ DISPLAY-PROGRAMMIERUNG (LVGL v9)

### Memory Management (Kritisch für 60 FPS)

**Problem:** LVGL braucht viel RAM für Rendering.

**Lösung: Double Buffering im PSRAM**

```c
// lv_conf.h
#define LV_DISPLAY_DEF_REFR_PERIOD 16  // 60 FPS (16ms)
#define LV_COLOR_DEPTH 16              // RGB565
#define LV_MEM_CUSTOM 1                // Custom Memory Handler
#define LV_MEM_CUSTOM_INCLUDE <stdlib.h>

// Framebuffer im PSRAM (nicht SRAM!)
static uint16_t framebuffer1[172 * 320] PSRAM_ATTR;
static uint16_t framebuffer2[172 * 320] PSRAM_ATTR;
```

**Display-Treiber mit DMA:**

```c
// hal/display.c
void display_init(void) {
    // SPI-DMA Konfiguration
    spi_bus_config_t buscfg = {
        .mosi_io_num = GPIO_NUM_41,
        .mosi_dma_chan = SPI_DMA_CH_AUTO,
        .sclk_io_num = GPIO_NUM_40,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 172 * 320 * 2,  // Vollständiger Framebuffer
    };
    
    spi_bus_initialize(SPI2_HOST, &buscfg, SPI_DMA_CH_AUTO);
    
    // ST7789 Treiber initialisieren
    // ... weitere Konfiguration
}

// Asynchroner Framebuffer-Transfer
void display_flush(lv_display_t* disp, const lv_area_t* area, uint8_t* px_map) {
    // DMA-Transfer (CPU bleibt frei)
    spi_transaction_t t = {
        .length = (area->x2 - area->x1 + 1) * (area->y2 - area->y1 + 1) * 16,
        .tx_buffer = px_map,
    };
    spi_device_queue_trans(spi, &t, portMAX_DELAY);
    
    // Callback wenn fertig
    lv_display_flush_ready(disp);
}
```

### Touch-Treiber (CST816S)

```c
// hal/touch.c
#include "driver/i2c_master.h"

#define CST816S_ADDR 0x15
#define I2C_SDA_PIN GPIO_NUM_17
#define I2C_SCL_PIN GPIO_NUM_18

void touch_init(void) {
    i2c_master_bus_config_t i2c_mst_config = {
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .i2c_port = I2C_NUM_0,
        .scl_io_num = I2C_SCL_PIN,
        .sda_io_num = I2C_SDA_PIN,
        .glitch_ignore_cnt = 7,
    };
    
    i2c_master_bus_handle_t bus_handle;
    i2c_new_master_bus(&i2c_mst_config, &bus_handle);
    
    // CST816S Device hinzufügen
    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_7,
        .device_address = CST816S_ADDR,
        .scl_speed_hz = 400000,
    };
    
    i2c_master_bus_add_device(bus_handle, &dev_cfg, &touch_handle);
}

// Touch-Daten auslesen
void touch_read(lv_indev_t* indev, lv_indev_data_t* data) {
    uint8_t buf[6];
    i2c_master_receive(touch_handle, buf, 6, -1);
    
    // Parsing
    uint8_t gesture = buf[1];
    uint16_t x = ((buf[2] & 0x0F) << 8) | buf[3];
    uint16_t y = ((buf[4] & 0x0F) << 8) | buf[5];
    
    data->point.x = x;
    data->point.y = y;
    data->state = (gesture == 0) ? LV_INDEV_STATE_RELEASED : LV_INDEV_STATE_PRESSED;
}
```

### Smooth Animations (60 FPS)

**Problem:** Animationen sehen ruckelig aus.

**Lösung: Easing-Funktionen + Dual-Core**

```c
// ui/animations.c
#include "lvgl.h"

// Easing-Funktion (ease-out-cubic)
int32_t ease_out_cubic(int32_t t, int32_t b, int32_t c, int32_t d) {
    t /= d;
    t--;
    return c * (t * t * t + 1) + b;
}

// Carousel-Animation
void carousel_animate(lv_obj_t* carousel, int32_t target_x) {
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, carousel);
    lv_anim_set_values(&a, lv_obj_get_x(carousel), target_x);
    lv_anim_set_time(&a, 300);  // 300ms Animation
    lv_anim_set_exec_cb(&a, (lv_anim_exec_xcb_t)lv_obj_set_x);
    lv_anim_set_path_cb(&a, lv_anim_path_ease_out);
    lv_anim_start(&a);
}
```

**Dual-Core Nutzung:**

```c
// main.c
void app_main(void) {
    // Core 0: System Tasks (WiFi, NTP, OTA)
    xTaskCreatePinnedToCore(system_task, "system", 4096, NULL, 1, NULL, 0);
    
    // Core 1: UI Rendering (LVGL)
    xTaskCreatePinnedToCore(ui_task, "ui", 8192, NULL, 2, NULL, 1);
}

void ui_task(void* arg) {
    while(1) {
        lv_timer_handler();  // LVGL Rendering
        vTaskDelay(pdMS_TO_TICKS(16));  // 60 FPS (16ms)
    }
}
```

---

## 📡 CONNECTIVITY & UPDATES

### WiFi-Verbindung (Robust)

**Problem:** ESP32 verliert WiFi-Verbindung.

**Lösung: Auto-Reconnect mit Exponential Backoff**

```c
// hal/wifi.c
#include "esp_wifi.h"
#include "esp_event.h"

static uint8_t reconnect_count = 0;
static const uint8_t MAX_RECONNECT = 5;

void wifi_event_handler(void* arg, esp_event_base_t event_base,
                        int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        if (reconnect_count < MAX_RECONNECT) {
            reconnect_count++;
            uint32_t delay_ms = 1000 * (1 << reconnect_count);  // Exponential backoff
            ESP_LOGI(TAG, "WiFi lost! Reconnecting in %ld ms", delay_ms);
            esp_wifi_connect();
        }
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        reconnect_count = 0;  // Reset counter
        ESP_LOGI(TAG, "WiFi connected!");
    }
}

void wifi_init(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    
    esp_netif_create_default_wifi_sta();
    
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, 
                                               &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, 
                                               &wifi_event_handler, NULL));
    
    wifi_config_t wifi_config = {
        .sta = {
            .ssid = CONFIG_WIFI_SSID,
            .password = CONFIG_WIFI_PASSWORD,
        },
    };
    
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
}
```

### NTP Time Synchronization

```c
// hal/ntp.c
void ntp_sync(void) {
    // Timezone für Deutschland (automatische Sommer-/Winterzeit)
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    setenv("TZ", "CET-1CEST,M3.5.0,M10.5.0/3", 1);
    tzset();
    
    // Warten auf Synchronisation
    time_t now = time(NULL);
    struct tm timeinfo = *localtime(&now);
    int retry = 0;
    
    while (timeinfo.tm_year < (2016 - 1900) && ++retry < 20) {
        vTaskDelay(pdMS_TO_TICKS(500));
        time(&now);
        localtime_r(&now, &timeinfo);
    }
    
    ESP_LOGI(TAG, "Time synchronized: %s", asctime(&timeinfo));
}
```

### OTA Updates (Over-The-Air)

```c
// hal/ota.c
#include "esp_ota_ops.h"
#include "esp_http_client.h"
#include "esp_https_ota.h"

void ota_update(const char* url) {
    esp_http_client_config_t config = {
        .url = url,
        .cert_pem = (char *)server_cert_pem_start,  // Verschlüsselt!
    };
    
    esp_https_ota_config_t ota_config = {
        .http_config = &config,
    };
    
    esp_err_t ret = esp_https_ota(&ota_config);
    if (ret == ESP_OK) {
        esp_restart();
    } else {
        ESP_LOGE(TAG, "OTA failed: %s", esp_err_to_name(ret));
    }
}
```

---

## 🎨 THEME-SYSTEM (Chameleon-spezifisch)

### ThemeManager Implementierung

```c
// ui/theme_manager.c
#include "lvgl.h"

typedef struct {
    lv_color_t primary;
    lv_color_t secondary;
    lv_color_t accent;
    lv_color_t background;
    lv_color_t text;
    uint8_t border_width;
    uint16_t animation_speed;
} theme_t;

// Vordefinierte Themes
const theme_t theme_obsidian_gold = {
    .primary = lv_color_hex(0x1a1a1a),
    .secondary = lv_color_hex(0xd4af37),
    .accent = lv_color_hex(0xffd700),
    .background = lv_color_hex(0x0d0d0d),
    .text = lv_color_hex(0xffffff),
    .border_width = 2,
    .animation_speed = 300,
};

const theme_t theme_nordic_white = {
    .primary = lv_color_hex(0xffffff),
    .secondary = lv_color_hex(0x2c3e50),
    .accent = lv_color_hex(0x3498db),
    .background = lv_color_hex(0xecf0f1),
    .text = lv_color_hex(0x2c3e50),
    .border_width = 1,
    .animation_speed = 250,
};

static theme_t current_theme = theme_obsidian_gold;

void theme_apply(const theme_t* theme) {
    current_theme = *theme;
    
    // Alle UI-Elemente aktualisieren
    lv_obj_t* root = lv_screen_active();
    apply_theme_recursive(root, theme);
}

void apply_theme_recursive(lv_obj_t* obj, const theme_t* theme) {
    if (obj == NULL) return;
    
    // Hintergrund
    lv_obj_set_style_bg_color(obj, theme->background, LV_PART_MAIN);
    
    // Text
    lv_obj_set_style_text_color(obj, theme->text, LV_PART_MAIN);
    
    // Border
    lv_obj_set_style_border_color(obj, theme->secondary, LV_PART_MAIN);
    lv_obj_set_style_border_width(obj, theme->border_width, LV_PART_MAIN);
    
    // Kinder rekursiv
    uint32_t child_count = lv_obj_get_child_count(obj);
    for (uint32_t i = 0; i < child_count; i++) {
        apply_theme_recursive(lv_obj_get_child(obj, i), theme);
    }
}
```

---

## 🔄 DEBUGGING & TROUBLESHOOTING

### Serial Monitor Best Practices

```c
void setup_logging(void) {
    // Serielle Verbindung initialisieren
    esp_log_level_set("*", ESP_LOG_INFO);
    esp_log_level_set("esp_psram", ESP_LOG_DEBUG);
    
    // Boot-Informationen
    ESP_LOGI(TAG, "\n\n=== CHAMELEON OS Boot ===");
    ESP_LOGI(TAG, "Chip Model: %s", esp_chip_info_t.model);
    ESP_LOGI(TAG, "Chip Revision: %d", esp_chip_info_t.revision);
    ESP_LOGI(TAG, "CPU Freq: %d MHz", esp_clk_cpu_freq() / 1000000);
    ESP_LOGI(TAG, "Free Heap: %ld bytes", esp_get_free_heap_size());
    ESP_LOGI(TAG, "Free PSRAM: %ld bytes", esp_psram_get_size() - esp_psram_get_free_size());
}
```

### Häufige Fehler & Lösungen

#### 1. "Brownout detector was triggered"
**Ursache:** Spannungsabfall (USB-Port zu schwach)

**Lösung:**
- USB-Hub mit eigener Stromversorgung verwenden
- Oder direkt an PC-USB-Port (nicht Monitor)
- Power-Consumption reduzieren (WiFi, Display)

#### 2. "Display bleibt schwarz"
**Ursache:** Falsche Pins oder SPI-Konfiguration

**Lösung: Pin-Verifikation**
```c
// Teste jeden Pin einzeln
void test_pins(void) {
    // SPI-Pins
    gpio_set_direction(GPIO_NUM_40, GPIO_MODE_OUTPUT);  // SCLK
    gpio_set_direction(GPIO_NUM_41, GPIO_MODE_OUTPUT);  // MOSI
    
    // Display-Kontroll-Pins
    gpio_set_direction(GPIO_NUM_39, GPIO_MODE_OUTPUT);  // DC
    gpio_set_direction(GPIO_NUM_37, GPIO_MODE_OUTPUT);  // CS
    gpio_set_direction(GPIO_NUM_36, GPIO_MODE_OUTPUT);  // RST
    
    // Test: Alle Pins toggeln
    for(int i = 0; i < 10; i++) {
        gpio_set_level(GPIO_NUM_40, 1);
        vTaskDelay(pdMS_TO_TICKS(100));
        gpio_set_level(GPIO_NUM_40, 0);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}
```

#### 3. "LVGL rendering is slow (< 30 FPS)"
**Ursache:** PSRAM nicht aktiviert oder falsche Puffergröße

**Lösung:**
- `idf.py menuconfig` → PSRAM aktivieren
- Framebuffer in PSRAM, nicht SRAM
- DMA für Display-Transfer verwenden
- Dual-Core nutzen (Core 1 nur für UI)

#### 4. "Touch funktioniert nicht"
**Ursache:** I2C-Kommunikation fehlgeschlagen

**Lösung: I2C-Scanner**
```c
void scan_i2c(void) {
    i2c_master_bus_config_t i2c_mst_config = {
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .i2c_port = I2C_NUM_0,
        .scl_io_num = GPIO_NUM_18,
        .sda_io_num = GPIO_NUM_17,
    };
    
    i2c_master_bus_handle_t bus_handle;
    i2c_new_master_bus(&i2c_mst_config, &bus_handle);
    
    for(uint8_t addr = 1; addr < 127; addr++) {
        i2c_device_config_t dev_cfg = {
            .dev_addr_length = I2C_ADDR_BIT_7,
            .device_address = addr,
        };
        
        i2c_master_dev_handle_t dev_handle;
        if(i2c_master_bus_add_device(bus_handle, &dev_cfg, &dev_handle) == ESP_OK) {
            ESP_LOGI(TAG, "I2C device found at 0x%02X", addr);
            i2c_master_bus_rm_device(dev_handle);
        }
    }
}
```

---

## 🚀 PERFORMANCE-OPTIMIERUNG

### Memory Monitoring

```c
void print_memory_stats(void) {
    ESP_LOGI(TAG, "=== Memory Stats ===");
    ESP_LOGI(TAG, "Free Heap: %ld / %ld bytes (%.1f%%)",
        esp_get_free_heap_size(),
        esp_get_heap_size(),
        (float)esp_get_free_heap_size() / esp_get_heap_size() * 100);
    
    ESP_LOGI(TAG, "Free PSRAM: %ld / %ld bytes (%.1f%%)",
        esp_psram_get_free_size(),
        esp_psram_get_size(),
        (float)esp_psram_get_free_size() / esp_psram_get_size() * 100);
    
    ESP_LOGI(TAG, "Largest free block: %ld bytes", 
        heap_caps_get_largest_free_block(MALLOC_CAP_DEFAULT));
}
```

### Non-blocking Loop

```c
void ui_task(void* arg) {
    uint32_t last_update = 0;
    const uint32_t update_interval = 16;  // 60 FPS
    
    while(1) {
        uint32_t now = esp_timer_get_time() / 1000;  // ms
        
        if(now - last_update >= update_interval) {
            last_update = now;
            
            // UI-Update
            lv_timer_handler();
        }
        
        // Andere Tasks können laufen
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}
```

---

## 🔐 SECURITY BEST PRACTICES

### Credentials Management

**❌ NIEMALS Credentials in Git committen!**

**Lösung: CMake-Variablen**

```cmake
# CMakeLists.txt
idf_component_register(
    SRCS "main.c"
    INCLUDE_DIRS "."
)

# Credentials aus Umgebungsvariablen
target_compile_definitions(${COMPONENT_LIB} PRIVATE
    WIFI_SSID=\"${WIFI_SSID}\"
    WIFI_PASSWORD=\"${WIFI_PASSWORD}\"
    MQTT_SERVER=\"${MQTT_SERVER}\"
)
```

**Build mit Credentials:**
```bash
export WIFI_SSID="MyWiFi"
export WIFI_PASSWORD="secret123"
export MQTT_SERVER="192.168.1.100"

idf.py build
```

### OTA-Security

```c
// Nur signierte Updates akzeptieren
esp_https_ota_config_t ota_config = {
    .http_config = &config,
    .partial_http_download = true,
    .max_http_request_size = 4096,
};

// Zertifikat validieren
extern const uint8_t server_cert_pem_start[] asm("_binary_server_cert_pem_start");
extern const uint8_t server_cert_pem_end[] asm("_binary_server_cert_pem_end");
```

---

## 📋 WORKFLOW-EMPFEHLUNGEN FÜR AGENTEN

### 1. Projekt-Setup Phase

- [ ] Hardware-Version verifizieren (ESP32-S3!)
- [ ] ESP-IDF v5.1+ installieren
- [ ] PSRAM aktivieren (menuconfig)
- [ ] Pins verifizieren (Display, Touch, WiFi)
- [ ] Basis-Test: Display-Initialisierung
- [ ] Basis-Test: Touch-Initialisierung
- [ ] Basis-Test: WiFi-Verbindung

### 2. Feature-Entwicklung (Inkrementell)

```
Iteration 1: Display funktioniert (schwarz/weiß)
    ↓
Iteration 2: LVGL initialisiert
    ↓
Iteration 3: Carousel-Navigation
    ↓
Iteration 4: Erste App (Dummy)
    ↓
Iteration 5: Erste App (Funktionsfähig)
    ↓
Iteration 6: Performance optimieren (60 FPS)
```

### 3. Testing-Strategie

**Nach jedem Build:**
- [ ] Kompilieren ohne Fehler
- [ ] Flash erfolgreich
- [ ] Serial Monitor zeigt Boot-Meldungen
- [ ] Display funktioniert
- [ ] Touch funktioniert
- [ ] WiFi verbindet
- [ ] Performance OK (FPS, RAM)

### 4. Code-Review Checkliste

- [ ] Keine hardcoded Credentials
- [ ] Alle großen Datenstrukturen in PSRAM
- [ ] Non-blocking Code (kein delay() in Loops)
- [ ] Error-Handling (WiFi, Touch, Display)
- [ ] Memory-Leaks geprüft
- [ ] Kommentare für komplexe Logik
- [ ] Git-Commit mit aussagekräftiger Nachricht

---

## 📚 NÜTZLICHE RESSOURCEN

### Offizielle Dokumentation
- **ESP-IDF Docs:** https://docs.espressif.com/projects/esp-idf/
- **ESP32-S3 Datasheet:** https://www.espressif.com/sites/default/files/documentation/esp32-s3_datasheet_en.pdf
- **LVGL Docs:** https://docs.lvgl.io/
- **Waveshare Docs:** https://www.waveshare.com/wiki/ESP32-S3-Touch-LCD-1.47

### Tools
- **ESP-IDF Monitor:** `idf.py monitor`
- **I2C Scanner:** Siehe Debugging-Sektion
- **Memory Profiler:** `heap_trace_init_standalone()`
- **Performance Profiler:** `esp_timer_get_time()`

---

## ✅ QUICK REFERENCE

### Häufige Aufgaben

**Display initialisieren:**
```c
display_init();  // ST7789 + DMA
lv_init();       // LVGL
```

**Touch initialisieren:**
```c
touch_init();    // CST816S
lv_indev_create(touch_read);
```

**WiFi verbinden:**
```c
wifi_init();     // Auto-Reconnect
ntp_sync();      // Zeit synchronisieren
```

**App starten:**
```c
app_init();      // App-Grundgerüst
app_start();     // App-Logik
```

**Performance messen:**
```c
print_memory_stats();  // RAM/PSRAM
lv_refr_get_fps_count();  // FPS
```

---

## 🎯 ZUSAMMENFASSUNG

**Chameleon OS ist ein hochperformantes System mit klaren Best Practices:**

1. ✅ PSRAM ist essentiell (Double Buffering, DMA)
2. ✅ Dual-Core nutzen (Core 0: System, Core 1: UI)
3. ✅ Non-blocking Code (kein delay() in Loops)
4. ✅ Modulare Architektur (Apps sind unabhängig)
5. ✅ Robuste Fehlerbehandlung (WiFi, Touch, Display)
6. ✅ Sichere Credentials (nie in Git!)
7. ✅ Iterative Entwicklung (Dummy → Funktionsfähig → Abgelegt)

**Mit diesen Best Practices wird Chameleon OS zu einem stabilen, performanten System.**
